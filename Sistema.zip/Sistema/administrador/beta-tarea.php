a<?php
if(!empty($_GET['departamento'])) {
    $departamento = $_GET['departamento'];
}else{
      header("Location: administrador/");
}
require_once 'includes/header.php';
require_once '../includes/conexion.php';
require_once 'includes/modals/modal_tareas.php';

$usuario_id = $_SESSION['id_usuario'];
        
        

 $sql = "SELECT *, date_format(fecha_limite, '%d/%m/%Y') as fecha_limite FROM lista_tareas WHERE departamento_id = $departamento";
 $query = $pdo->prepare($sql);
 $query->execute();
 $row = $query->rowCount();

?>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Tareas</h1>
           <button class="btn btn-success" type="button" onclick="openModalBtareas()">Nuevo Tarea</button> 
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Tarea a Evaluar</a></li>
        </ul>
      </div>
      <div class="row">
        <?php if($row > 0){
              while($data = $query->fetch()){
                ?>
        <div class="col-md-12">
          <div class="tile">
          <div class="tile">
              <div class = "tile-tile-w-btn">
                    <h3 class="title"><?= $data['tarea']; ?></h3>
                    <p><button class="btn btn-info icon-btn" onclick="editarTarea(<?= $data['tarea_id']; ?>)"><i class="fa fa-edit"></i>Editar Tarea</button> <button class="btn btn-danger icon-btn" onclick="eliminarTarea(<?= $data['tarea_id']; ?>)"><i class="fa fa-delet"></i>Eliminar Tarea</button> <a  class="btn btn-warning icon-btn" href="progreso.php?departamento=<?= $data['departamento_id']; ?>&eva=<?= $data['tarea_id']; ?>"><i class="fa fa-edit"></i>Ver Progreso</a></p>
              </div>
              <div class="tile-body">
                  <b><?= $data['descripcion']; ?></b> <br><br>
                  <b> Fecha limite:  <kbd class="bg-info"> <?= $data['fecha_limite']; ?></kbd></b><br>
                  <?php 
                  if($data['prioridad'] == 1) {
                    echo 'Prioridad: ','<span class = "badge badge-success">Normal</span>';
                } elseif ($data['prioridad'] == 2) {
                    echo 'Prioridad: ', '<span class = "badge badge-warning">Urgente</span>';
                } else{
                  echo 'Prioridad: ', '<span class = "badge badge-danger">Inmediata</span>';
              }
                  ?>
                  
              </div>
            </div>
          </div>
        </div>
        <?php   } }?>
      </div>
              <div class="row">
                  <a href="departamentos.php" class="btn btn-info"><< Volver Atras</a>
              </div>
    </main>-->

<?php
require_once 'includes/footer.php'
?>