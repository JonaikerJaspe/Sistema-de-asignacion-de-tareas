<?php
require_once '../../../includes/conexion.php';

if(!empty($_POST)) {
    if(empty($_POST['nombre']) || empty($_POST['descripcion']) ){
        $respuesta = array('status' => false,'msg' => 'Todos los campos son necesarios');
    } else {
        $iddepartamentos = $_POST['iddepartamentos'];
        $departamento = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $estado = $_POST['listEstado'];

        
        $sql = 'SELECT * FROM departamentos WHERE nombre_departamento != ? AND departamento_id = ? ';
        $query = $pdo->prepare($sql);
        $query->execute(array($iddepartamentos,$departamento));
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result > 0){
            $respuesta = array('status' => false, 'msg' => 'El departamento ya existe');
        }else{
            if($iddepartamentos == 0) {
                $sqlInsert = 'INSERT INTO departamentos (nombre_departamento,descripcion,estado) VALUES (?,?,?)';
                $queryInsert = $pdo->prepare($sqlInsert);
                $request = $queryInsert->execute(array($departamento,$descripcion,$estado));
                $accion = 1;
            }else{
                $sqlUpdate = 'UPDATE departamentos SET nombre_departamento = ?, descripcion = ?, estado = ? WHERE departamento_id = ?';
                $queryUpdate = $pdo->prepare($sqlUpdate);
                $request= $queryUpdate->execute(array($departamento,$descripcion,$estado,$iddepartamentos,));
                $accion = 2;
                
            }
           

            if($request > 0){
                if($accion == 1){
                    $respuesta = array('status'=> true,'msg' => 'Usuario creado correctamente' );
                }else{
                    $respuesta = array('status'=> true,'msg' => 'Usuario actualizado correctamente');
    
                }
            }
        }
         
    }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}

?>