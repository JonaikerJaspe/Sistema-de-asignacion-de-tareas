<?php

require_once '../../../includes/conexion.php';

if($_POST){
    $iddepartamento = $_POST['iddepartamento'];

    $sql = "SELECT * FROM departamentos  WHERE departamento_id = ?";
    $query = $pdo->prepare($sql);
    $query->execute(array($iddepartamento)); 
    $data = $query->fetch(PDO::FETCH_ASSOC); 
    
    $sqle = "SELECT * FROM lista_tareas  WHERE departamento_id = ?";
    $querye = $pdo->prepare($sqle);
    $querye->execute(array($iddepartamento)); 
    $data2 = $querye->fetch(PDO::FETCH_ASSOC);
    
    if(empty($data2)) {
    $sql_update = "DELETE FROM departamentos  WHERE departamento_id  = ?";
    $query_update = $pdo->prepare($sql_update);
    $result = $query_update->execute(array($iddepartamento)); 
    if ($result) {
      if($data['descripcion'] != '') {
        unlink($data['descripcion']);
      }
      $arrResponse = array('status' => true,'msg' => 'Eliminado Correctamente');
    } else {
      $arrResponse = array('status' => false,'msg' => 'Error al eliminar');
      
      } 
    
    } else { 
      $arrResponse = array('status' => false,'msg' => 'No se puede eliminar, ya tiene tareas asignada ');
      
    }
    
    echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
}