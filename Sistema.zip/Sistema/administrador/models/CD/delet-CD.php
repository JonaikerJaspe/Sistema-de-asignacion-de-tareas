<?php

require_once '../../../includes/conexion.php';

if($_POST){
    $idCD = $_POST['idCD'];

    $sql = "UPDATE departamento_coordinador SET estadocd = 0 WHERE dc_id = ?";
    $query = $pdo->prepare($sql);
    $result = $query->execute(array($idCD)); 
    
    if($result){
        $respuesta = array('status' => true,'msg' => 'Proceso eliminado correctamente');
    } else {
        $respuesta = array('status' => false,'msg' => 'Error al eliminar');
    }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}