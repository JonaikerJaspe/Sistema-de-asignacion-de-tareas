<?php

require_once '../../../includes/conexion.php';

if(!empty($_POST)) {
    if(empty($_POST['listDepartamento']) || empty($_POST['listCoordinadores'])){
        $arrResponse = array('status' => false,'msg' => 'Todos los campos son necesarios');
    } else {
        $idCD = $_POST['idCD'];
        $nombre = $_POST['listCoordinadores'];
        $departamento = $_POST['listDepartamento'];
        $estado = $_POST['listEstado'];
        
        //CONSULTA PARA INSERTAR
        $sql = 'SELECT * FROM departamento_coordinador WHERE departamento_id != ? AND coordinador_id = ? AND estadocd != 0 ';
        $query = $pdo->prepare($sql);
        $query->execute(array( $departamento,$nombre));
        $resultInsert = $query->fetch(PDO::FETCH_ASSOC);

        //CONSULTA PARA ACTUALIZAR
        $sql2 = 'SELECT * FROM departamento_coordinador WHERE departamento_id != ? AND coordinador_id = ? AND estadocd != 0 AND dc_id != ?';
        $query = $pdo->prepare($sql2);
        $query->execute(array($departamento,$nombre,$idCD));
        $resultUpdate = $query->fetch(PDO::FETCH_ASSOC);

        if($resultInsert > 0) {
            $arrResponse = array ('status' => false, 'msg' => 'El departamento y el coordinador ya existen, seleccione otro');    
        }else{
            if($idCD == 0) {
                $sql_insert = "INSERT INTO departamento_coordinador (departamento_id,coordinador_id,estadocd) VALUES (?,?,?)";
                $query_insert = $pdo ->prepare($sql_insert);
                $request = $query_insert-> execute(array($departamento,$nombre,$estado));
                if($request){
                    $arrResponse = array('status' => true, 'msg' => 'Proceso creado correctamente' );
                }
            }
        }

        if($resultUpdate > 0) {
            $arrResponse = array ('status' => false, 'msg' => 'El departamento y el coordinador ya existen, seleccione otro');    
        }else{
            if( $idCD > 0) {
                $sql_update = "UPDATE  departamento_coordinador SET departamento_id = ?, coordinador_id = ?, estadocd = ? WHERE dc_id = ?";
                $query_Update = $pdo->prepare($sql_update);
                $request2 = $query_Update-> execute(array($departamento,$nombre,$estado,$idCD));
                if($request2){
                    $arrResponse = array('status' => true, 'msg' => 'Proceso creado correctamente' );
                }
            }
        }
    }
    echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
}

?>