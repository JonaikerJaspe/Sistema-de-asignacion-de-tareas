<?php
require_once '../../../includes/conexion.php';

if(!empty($_POST)) {
    if(trim($_POST['calificacion']) == '' ){
        $respuesta = array('status' => false,'msg' => 'Todos los campos son necesarios');
    } else {
        $idprogreso = $_POST['idprogreso'];
        $calificacion = $_POST['calificacion'];
       
         
          
                $sqlInsert = 'INSERT INTO calificacion (progreso_id,valor_calificacion) VALUES (?,?)';
                $queryInsert = $pdo->prepare($sqlInsert);
                $request = $queryInsert->execute(array( $idprogreso,$calificacion));
             
            if($request > 0){
                    $respuesta = array('status'=> true,'msg' => 'Tarea calificada correctamente' );
            }
        }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}

?>