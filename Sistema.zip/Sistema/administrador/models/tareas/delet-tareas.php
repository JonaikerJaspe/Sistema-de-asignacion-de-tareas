<?php

require_once '../../../includes/conexion.php';

if($_POST){
    $idtarea = $_POST['idtarea'];
    
    $sql_update = "DELETE FROM lista_tareas WHERE tarea_id = ?";
    $query_update = $pdo->prepare($sql_update);
    $result = $query_update->execute(array($idtarea)); 
    if ($result) {
      
      $arrResponse = array('status' => true,'msg' => 'Eliminado Correctamente');
    } else {
      $arrResponse = array('status' => false,'msg' => 'Error al eliminar');
      
      } 
    
    echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
}