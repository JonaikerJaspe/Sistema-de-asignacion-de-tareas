<?php
require_once '../../../includes/conexion.php';

if(!empty($_POST)) {
    if(empty($_POST['tarea']) || empty($_POST['descripcion']) || empty($_POST['rendimiento']) || empty($_POST['fecha_limite']) ){
        $respuesta = array( 'status' => false,'msg' => 'Todos los campos son necesarios');
    } else {
        $idtarea = $_POST['idtarea'];
        $iddepartamentos = $_POST['iddepartamentos'];
        $tarea = $_POST['tarea'];
        $descripcion = $_POST['descripcion'];
        $rendimiento = $_POST['rendimiento'];
        $fecha_limite = $_POST['fecha_limite'];
        $prioridad = $_POST['listPrioridad'];

        
        /*$sql = 'SELECT * FROM lista_tareas WHERE tarea = ? AND departamento_id != ? AND tarea_id != ? ';
        $query = $pdo->prepare($sql);
        $query->execute(array($idtarea,$iddepartamentos,$tarea));
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result > 0){
            $respuesta = array('status' => false, 'msg' => 'El departamento ya existe');
        }else{*/
            if($idtarea == 0) {
                $sqlInsert = 'INSERT INTO lista_tareas(tarea,descripcion,departamento_id,rendimiento,fecha_limite,prioridad) VALUES (?,?,?,?,?,?)';
                $queryInsert = $pdo->prepare($sqlInsert);
                $request = $queryInsert->execute(array($tarea,$descripcion,$iddepartamentos,$rendimiento,$fecha_limite,$prioridad));
                $accion = 1;
            }else{
                $sqlUpdate = 'UPDATE lista_tareas SET tarea = ?, descripcion = ?, departamento_id = ?, rendimiento = ?, fecha_limite = ?,prioridad = ? WHERE tarea_id = ?';
                $queryUpdate = $pdo->prepare($sqlUpdate);
                $request= $queryUpdate->execute(array($tarea,$descripcion,$iddepartamentos,$rendimiento,$fecha_limite,$prioridad,$idtarea));
                $accion = 2;
                
            }
           

            if($request > 0){
                if($accion == 1){
                    $respuesta = array('status'=> true,'msg' => 'Usuario creado correctamente' );
                }else{
                    $respuesta = array('status'=> true,'msg' => 'Usuario actualizado correctamente');
    
                }
            }
        
         
    }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}

?>
