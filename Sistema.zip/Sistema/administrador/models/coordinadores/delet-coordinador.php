<?php

require_once '../../../includes/conexion.php';

if($_POST){
    $idCoordinadores = $_POST['idCoordinadores'];

    $sql = "UPDATE coordinadores SET estado = 0 WHERE coordinador_id = ?";
    $query = $pdo->prepare($sql);
    $result = $query->execute(array( $idCoordinadores)); 
    
    if($result){
        $respuesta = array('status' => true,'msg' => 'Coordinador eliminado correctamente');
    } else {
        $respuesta = array('status' => false,'msg' => 'Error al eliminar');
    }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}