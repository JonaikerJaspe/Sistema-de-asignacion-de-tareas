<?php

require_once '../../../includes/conexion.php';

if(!empty($_POST)) {
    if(empty($_POST['nombre']) || empty($_POST['cedula']) || empty($_POST['telefono']) || empty($_POST['correo']) ){
        $respuesta = array('status' => false,'msg' => 'Todos los campos son necesarios');
    } else {
        $idcoordinador = $_POST['idCoordinadores'];
        $nombre = $_POST['nombre'];
        $cedula = $_POST['cedula'];
        $clave = $_POST['clave'];
        $telefono = $_POST['telefono'];
        $correo = $_POST['correo'];
        $estado = $_POST['listEstado'];
          
        $sql = 'SELECT * FROM coordinadores WHERE cedula = ? AND coordinador_id != ? AND estado != 0';
        $query = $pdo->prepare($sql);
        $query->execute(array($cedula,$idcoordinador,));
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($result > 0){
            $respuesta = array('status' => false, 'msg' => 'El coordinador ya existe');
        }else{
            if($idcoordinador == 0) {
                $clave = password_hash($clave,PASSWORD_DEFAULT); 
                $sqlInsert = 'INSERT INTO coordinadores (nombre,cedula,clave,telefono,correo,estado) VALUES (?,?,?,?,?,?)';
                $queryInsert = $pdo->prepare($sqlInsert);
                $request = $queryInsert->execute(array($nombre,$cedula,$clave,$telefono,$correo,$estado));
                $accion = 1;
            }else{
                if(empty($clave)){
                    $sqlUpdate = 'UPDATE coordinadores SET nombre = ?,cedula = ?,telefono = ?,correo = ?,estado = ? WHERE coordinador_id = ?';
                    $queryUpdate = $pdo->prepare($sqlUpdate);
                    $request= $queryUpdate->execute(array($nombre,$cedula,$telefono,$correo,$estado,$idcoordinador));
                    $accion = 2;
                } else {
                    $claveUpdate = password_hash($_POST['clave'],PASSWORD_DEFAULT);
                    $sqlUpdate = 'UPDATE coordinadores SET  nombre = ?,cedula = ?,clave = ?, telefono = ?,correo = ?,estado = ? WHERE coordinador_id = ?';
                    $queryUpdate = $pdo->prepare($sqlUpdate);
                    $request= $queryUpdate->execute(array($nombre,$cedula,$claveUpdate,$telefono,$correo,$estado,$idcoordinador));
                    $accion = 3;
                }
            }

            if($request > 0){
                if($accion == 1){
                    $respuesta = array('status'=> true,'msg' => 'Coordinador creado correctamente' );
                }else{
                    $respuesta = array('status'=> true,'msg' => 'Coordinador actualizado correctamente');
    
                }
            }
        }
         
    }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}

?>