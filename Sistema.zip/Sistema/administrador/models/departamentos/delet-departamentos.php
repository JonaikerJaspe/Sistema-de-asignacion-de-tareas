<?php

require_once '../../../includes/conexion.php';

if($_POST){
    $iddepartamento= $_POST['iddepartamento'];

    $sql = "UPDATE departamentos  SET estado = 0 WHERE departamento_id = ?";
    $query = $pdo->prepare($sql);
    $result = $query->execute(array($iddepartamento)); 
    
    if($result){
        $respuesta = array('status' => true,'msg' => 'Departamento eliminado correctamente');
    } else {
        $respuesta = array('status' => false,'msg' => 'Error al eliminar');
    }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
}