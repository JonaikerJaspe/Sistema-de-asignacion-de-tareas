<?php

require_once 'includes/header.php';
require_once '../includes/conexion.php';
require_once 'includes/modals/modal_departamentos.php';

 $usuario_id = $_SESSION['id_usuario'];
        
        

 $sql = 'SELECT * FROM departamentos WHERE estado != 0';
 $query = $pdo->prepare($sql);
 $query->execute();
 $row = $query->rowCount();
 
?>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-folder-open fa"></i> Departamentos</h1>
           <button class="btn btn-success" type="button" onclick="openModalDepas()">Nuevo Departamento</button> 
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">departamento</a></li>
        </ul>
      </div>
      <div class="row">
        <?php if($row > 0){
              while($data = $query->fetch()){
                ?>
        <div class="col-md-12">
          <div class="tile">
          <div class="tile">
              <div class = "tile-tile-w-btn">
                    <h3 class="title"><?= $data['nombre_departamento']; ?></h3>
                    <p><button class="btn btn-info icon-btn" onclick=" editarDepartamentos(<?= $data['departamento_id']; ?>)"><i class="fa fa-edit"></i>Editar Departamento</button> <button class="btn btn-danger icon-btn" onclick="eliminarDepartamentos(<?= $data['departamento_id']; ?>)"><i class="fa fa-delet"></i>Eliminar Departamento</button> <a  class="btn btn-warning icon-btn" href="beta-tarea.php?departamento=<?= $data['departamento_id']; ?>"><i class="fa fa-edit"></i>Asignar tarea</a></p>
              </div>
              
              <div class="tile-body">
                  <b> <?= $data['descripcion'];?></b><br>
              </div>
            </div>
          </div>
        </div>
        <?php } } ?>
      </div>
              <div class="row">
                  <a href="index.php" class="btn btn-info"><< Volver Atras</a>
              </div>
    </main>

<?php
require_once 'includes/footer.php'
?>