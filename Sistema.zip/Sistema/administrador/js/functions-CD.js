$('#tablecd').DataTable();
var tablecd;

document.addEventListener('DOMContentLoaded', function() {
    tablecd = $('#tablecd').DataTable({
        "aProcessing": true,
        "aServerSide": true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax": {
            "url": "./models/CD/table_CD.php",
            "dataSrc" : ""
        },
        "columns":[
            {"data":"acciones"},
            {"data":"dc_id"},
            {"data":"nombre_departamento"},
            {"data":"nombre"},
            {"data":"estadocd"},
        ],
        "responsive": true,
        "bDestroy": true,
        "iDisplayLength": 10,
        "order": [[0,"asc"]],
    });

    var formCD = document.querySelector('#formCD');
    formCD.onsubmit = function(e) {
        e.preventDefault();

        var idCD = document.querySelector('#idCD').value;
        var departamento = document.querySelector('#listDepartamento').value;
        var coordinador = document.querySelector('#listCoordinadores').value;
        var estado = document.querySelector('#listEstado').value;
      

        if(departamento == '' || coordinador == '' ) {
            swal('Atencion','Todos los campos son necesarios','error');
            return false;
        }

        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/CD/ajax-CD.php';
        var form = new FormData(formCD);
        request.open('POST', url,true);
        request.send(form);
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                if(data.status){
                    $('#modalCD').modal('hide');
                    formCD.reset();
                    swal('Proceso',data.msg,'success');
                    tablecd.ajax.reload();
                } else {
                    swal('Atencion',data.msg,'error');
                }
            }
        }
    }
})

    function openModalCD() {
        document.querySelector('#idCD').value = "";
        document.querySelector('#tituloModal').innerHTML = 'Nuevo Departamento';
        document.querySelector('#action').innerHTML = 'Guardar';
        document.querySelector('#formCD').reset();
        $('#modalCD').modal('show');
    }

    window.addEventListener('load',function(){
        showDepartamento();
        showCoordinador();
    },false);

    function showDepartamento(){
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var url = './models/options/options-departamentos.php';
            request.open('GET', url,true);
            request.send();
            request.onreadystatechange = function() {
                if(request.readyState == 4 && request.status == 200) {
                    var data = JSON.parse(request.responseText);
                    data.forEach(function(valor){
                        data += '<option value ="'+valor.departamento_id+'">'+valor.nombre_departamento+'</option>';
                    });
                    document.querySelector('#listDepartamento').innerHTML = data;
                }
            }
    }

    function  showCoordinador(){
        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/options/options-coordinadores.php';
        request.open('GET', url,true);
        request.send();
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                data.forEach(function(valor){
                    data += '<option value ="'+valor.coordinador_id+'">'+valor.nombre+'</option>';
                });
                document.querySelector('#listCoordinadores').innerHTML = data;
            }
        }
    }


    function editarCD(id) {
        var idCD = id;

        document.querySelector('#tituloModal').innerHTML = 'Actualizar Departamento';
        document.querySelector('#action').innerHTML = 'Actualizar';
    
        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/CD/edit-CD.php?idCD='+idCD;
        request.open('GET', url,true);
        request.send();
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                if(data.status){
                document.querySelector('#idCD').value = data.data.dc_id;
                document.querySelector('#listDepartamento').value = data.data.departamento_id;
                document.querySelector('#listCoordinadores').value = data.data.coordinador_id;
                document.querySelector('#listEstado').value = data.data.estado;
                    
                    $('#modalCD').modal('show');
                } else {
                    swal('Atention',data.msg,'error');
                }
            }
        }

    }

    function eliminarCD(id) {
        var  idCD = id;

        swal({
            title:"Eliminar Departamento",
            text:"Realmente desea eliminar el departamento",
            type:"warning",
            showCancelButton: true,
            confirmButtonText: "Si, eliminar",
            cancelButtonText:"No, cancelar",
            closeOnConfirm: false,
            closeOnCancel: true,
        },function(confirm){
            if(confirm){
                var request =(window.XMLHttpRequest) ? new XMLHttpRequest : new ActiveXObject('Microsoft.XMLHTTP');
                var url = './models/CD/delet-CD.php';
                request.open('POST', url,true);
                var strData = " idCD="+ idCD;
                request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                request.send(strData);
                request.onreadystatechange = function() {
                    if(request.readyState == 4 && request.status == 200) {
                        var data = JSON.parse(request.responseText);
                        if(data.status){
                            $('#modalCD').modal('hide');
                            formCD.reset();
                            swal('Eliminar',data.msg,'success');
                            tablecd.ajax.reload();
                        } else {
                            swal('Atention',data.msg,'error');
                        }
                    }
                }
            }
        })
    }
