$('#tabletareas').DataTable();
var tabletareas;

document.addEventListener('DOMContentLoaded', function() {
    tabletareas = $('#tabletareas').DataTable({
        "aProcessing": true,
        "aServerSide": true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax": {
            "url": "./models/tareas/table_tareas.php",
            "dataSrc" : ""
        },
        "columns":[
            {"data":"acciones"},
            {"data":"tarea_id"},
            {"data":"tarea"},
            {"data":"nombre_departamento"},
            {"data":"rendimiento"},
            {"data":"fecha_limite"},
            {"data":"prioridad"},
        ],
        "dom":"lBfrtip",
        "buttons":[
            {
                "extend": "copyHtml5",
                "text": "<i class='far fa-copy'></i> Copiar",
                "titleAttr": "Copiar",
                "ClassName": "btn btn-secondary"
            }, {
                "extend": "excelHtml5",
                "text": "<i class='far fa-excel'></i> Excel",
                "titleAttr": "Exportar a Excel",
                "ClassName": "btn btn-success"
            }, {
                "extend": "pdfHtml5",
                "text": "<i class='far fa-pdf'></i> PDF",
                "titleAttr": "Exportar a PDF",
                "ClassName": "btn btn-danger",
                "exportOptions":{
                    "columns": [ 1, 2, 3, 4, 5, 6, 7, 8 ]
                }
            },{
                "extend": "csvHtml5",
                "text": "<i class='far fa-excel'></i> CSV",
                "titleAttr": "Exportar a CSV",
                "ClassName": "btn btn-info"
            }
        ],
        "responsive": true,
        "bDestroy": true,
        "iDisplayLength": 10,
        "order": [[0,"asc"]],
    });

    var formTarea = document.querySelector('#formTarea');
    formTarea.onsubmit = function(e) {
        e.preventDefault();

        var idtarea = document.querySelector('#idtarea').value;
        var tarea = document.querySelector('#tarea').value;
        var departamento = document.querySelector('#listDepartamento').value;
        var rendimiento = document.querySelector('#rendimiento').value;
        var fecha_limite = document.querySelector('#fecha_limite').value;
        var prioridad = document.querySelector('#listPrioridad').value;
       
      

        if(tarea == '' || rendimiento == '' || fecha_limite == '' ) {
            swal('Atencion','Todos los campos son necesarios','error');
            return false;
        }

        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/tareas/ajax-tareas.php';
        var form = new FormData(formTarea);
        request.open('POST', url,true);
        request.send(form);
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                if(data.status){
                    $('#modalTarea').modal('hide');
                    formTarea.reset();
                    swal('Tarea',data.msg,'success');
                    tabletareas.ajax.reload();
                } else {
                    swal('Atencion',data.msg,'error');
                }
            }
        }
    }
})

function openModalTareas() {
    document.querySelector('#idtarea').value = "";
    document.querySelector('#tituloModal').innerHTML = 'Nuevo Departamento';
    document.querySelector('#action').innerHTML = 'Guardar';
    document.querySelector('#formTarea').reset();
    $('#modalTarea').modal('show');
}

window.addEventListener('load',function(){
    showDepartamento();
},false);

function showDepartamento(){
        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/options/options-departamentos.php';
        request.open('GET', url,true);
        request.send();
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                data.forEach(function(valor){
                    data += '<option value ="'+valor.departamento_id+'">'+valor.nombre_departamento+'</option>';
                });
                document.querySelector('#listDepartamento').innerHTML = data;
            }
        }
}

function editarDepartamentos(id) {
    var iddepartamento = id;

    document.querySelector('#tituloModal').innerHTML = 'Actualizar Departamento';
    document.querySelector('#action').innerHTML = 'Actualizar';
   
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    var url = './models/departamentos/edit-departamentos.php?iddepartamentos='+iddepartamento;
    request.open('GET', url,true);
    request.send();
    request.onreadystatechange = function() {
        if(request.readyState == 4 && request.status == 200) {
            var data = JSON.parse(request.responseText);
            if(data.status){
               document.querySelector('#iddepartamentos').value = data.data.departamento_id;
               document.querySelector('#nombre').value = data.data.nombre_departamento;
               document.querySelector('#listEstado').value = data.data.estado;
                
                 $('#modalTarea').modal('show');
            } else {
                swal('Atention',data.msg,'error');
            }
        }
    }

}

function eliminarDepartamentos(id) {
    var iddepartamento = id;

    swal({
        title:"Eliminar Departamento",
        text:"Realmente desea eliminar el departamento",
        type:"warning",
        showCancelButton: true,
        confirmButtonText: "Si, eliminar",
        cancelButtonText:"No, cancelar",
        closeOnConfirm: false,
        closeOnCancel: true,
    },function(confirm){
        if(confirm){
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest : new ActiveXObject('Microsoft.XMLHTTP');
            var url = './models/departamentos/delet-departamentos.php';
            request.open('POST', url,true);
            var strData = "iddepartamento="+iddepartamento;
            request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            request.send(strData);
            request.onreadystatechange = function() {
                if(request.readyState == 4 && request.status == 200) {
                    var data = JSON.parse(request.responseText);
                    if(data.status){
                        swal('Eliminar',data.msg,'success');
                        tabletareas.ajax.reload();
                    } else {
                        swal('Atention',data.msg,'error');
                    }
                }
            }
        }
    })
}
