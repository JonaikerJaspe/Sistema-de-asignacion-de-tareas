$('#tableCoordinadores').DataTable();
var tableCoordinadores;

document.addEventListener('DOMContentLoaded', function() {
    tableCoordinadores = $('#tableCoordinadores').DataTable({
        "aProcessing": true,
        "aServerSide": true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax": {
            "url": "./models/coordinadores/table_coordinadores.php",
            "dataSrc" : ""
        },
        "columns":[
            {"data":"acciones"},
            {"data":"coordinador_id"},
            {"data":"nombre"},
            {"data":"cedula"},
            {"data":"telefono"},
            {"data":"correo"},
            {"data":"estado"},
        ],
        "responsive": true,
        "bDestroy": true,
        "iDisplayLength": 10,
        "order": [[0,"asc"]],
    });

    var formCoordinadores = document.querySelector('#formCoordinadores');
    formCoordinadores.onsubmit = function(e) {
        e.preventDefault();

        var idCoordinadores = document.querySelector('#idcoor').value;
        var nombre = document.querySelector('#nombre').value;
        var cedula = document.querySelector('#cedula').value;
        var clave = document.querySelector('#clave').value;
        var telefono = document.querySelector('#telefono').value;
        var correo = document.querySelector('#correo').value;
        var estado = document.querySelector('#listEstado').value;

        if(nombre == '' || cedula == '' || telefono == ''|| correo == ''  ) {
            swal('Atencion','Todos los campos son necesarios','error');
            return false;
        }

        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/coordinadores/ajax-coordinadores.php';
        var form = new FormData(formCoordinadores);
        request.open('POST', url,true);
        request.send(form);
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                if(data.status){
                    $('#modalCoordinadores').modal('hide');
                    formCoordinadores.reset();
                    swal('Coordinador',data.msg,'success');
                    tableCoordinadores.ajax.reload();
                } else {
                    swal('Atencion',data.msg,'error');
                }
            }
        }
    }
})

function openModalCoordinadores() {
    document.querySelector('#idcoor').value = "";
    document.querySelector('#tituloModal').innerHTML = 'Nuevo Coordinador';
    document.querySelector('#action').innerHTML = 'Guardar';
    document.querySelector('#formCoordinadores').reset();
    $('#modalCoordinadores').modal('show');
}

/*window.addEventListener('load',function(){
    showDepartamento();
},false);

function showDepartamento(){
        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/options/options-departamentos.php';
        request.open('GET', url,true);
        request.send();
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                data.forEach(function(valor){
                    data += '<option value ="'+valor.departamento_id+'">'+valor.nombre_departamento+'</option>';
                });
                document.querySelector('#listDepartamento').innerHTML = data;
            }
        }
}*/

function editarCoordinadores(id) {
    var idCoordinadores = id;

    document.querySelector('#tituloModal').innerHTML = 'Actualizar Coordinador';
    document.querySelector('#action').innerHTML = 'Actualizar';
   
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    var url = './models/coordinadores/edit-coordinador.php?idCoordinadores='+idCoordinadores;
    request.open('GET', url,true);
    request.send();
    request.onreadystatechange = function() {
        if(request.readyState == 4 && request.status == 200) {
            var data = JSON.parse(request.responseText);
            if(data.status){
               document.querySelector('#idcoor').value = data.data.coordinador_id;
               document.querySelector('#nombre').value = data.data.nombre;
               document.querySelector('#cedula').value = data.data.cedula;
               document.querySelector('#telefono').value = data.data.telefono;
               document.querySelector('#correo').value = data.data.correo;
               document.querySelector('#listEstado').value = data.data.estado;
                
                 $('#modalCoordinadores').modal('show');
            } else {
                swal('Atention',data.msg,'error');
            }
        }
    }

}

function eliminarCordinadores(id) {
    var idCoordinadores = id;

    swal({
        title:"Eliminar Coordinador",
        text:"Realmente desea eliminar el coordinador",
        type:"warning",
        showCancelButton: true,
        confirmButtonText: "Si, eliminar",
        cancelButtonText:"No, cancelar",
        closeOnConfirm: false,
        closeOnCancel: true,
    },function(confirm){
        if(confirm){
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest : new ActiveXObject('Microsoft.XMLHTTP');
            var url = './models/coordinadores/delet-coordinador.php';
            request.open('POST', url,true);
            var strData = "idCoordinadores="+idCoordinadores;
            request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            request.send(strData);
            request.onreadystatechange = function() {
                if(request.readyState == 4 && request.status == 200) {
                    var data = JSON.parse(request.responseText);
                    if(data.status){
                        $('#modalCoordinadores').modal('hide');
                        formCoordinadores.reset();
                        swal('Eliminar',data.msg,'success');
                        tableCoordinadores.ajax.reload();
                    } else {
                        swal('Atention',data.msg,'error');
                    }
                }
            }
        }
    })
}
