
document.addEventListener('DOMContentLoaded', function() {
    var formCalificacion = document.querySelector('#formCalificacion');
    formCalificacion.onsubmit = function(e) {
        e.preventDefault();

        var idprogreso = document.querySelector('#idprogreso').value;
        var calificacion = document.querySelector('#calificacion').value;
      
      

        if(calificacion.trim() == '') {
            swal('Atencion','Todos los campos son necesarios','error');
            return false;
        }

        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/calificacion/ajax-calificacion.php';
        var form = new FormData(formCalificacion);
        request.open('POST', url,true);
        request.send(form);
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                if(data.status){
                swal({
                    title: "Tarea Calificada",
                    type: "success",
                    confirmButtonText: "Aceptar",
                    closeOnConfirm: true,
                }, function(confirm){
                    if(confirm){
                            $('#modalCalificacion').modal('hide');
                            location.reload();
                            formCalificacion.reset()
                    }
                })
            } else {
                swal('Atencion',data.msg,'error');
            }
            }
        }
    }
})

function modalCalificacion() {
    $('#modalCalificacion').modal('show');
}

function openModalobservacion() {
    $('#modalobservacion').modal('show');
}

