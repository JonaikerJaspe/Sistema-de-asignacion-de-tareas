$('#tabledepartamentos').DataTable();
var tabledepartamentos;

document.addEventListener('DOMContentLoaded', function() {
    tabledepartamentos = $('#tabledepartamentos').DataTable({
        "aProcessing": true,
        "aServerSide": true,
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
        },
        "ajax": {
            "url": "./models/departamentos/table_departamentos.php",
            "dataSrc" : ""
        },
        "columns":[
            {"data":"acciones"},
            {"data":"departamento_id"},
            {"data":"nombre_departamento"},
            {"data":"estado"},
        ],
        "responsive": true,
        "bDestroy": true,
        "iDisplayLength": 10,
        "order": [[0,"asc"]],
    });

    var formDepartamentos = document.querySelector('#formDepartamentos');
    formDepartamentos.onsubmit = function(e) {
        e.preventDefault();

        var iddepartamentos = document.querySelector('#iddepartamentos').value;
        var departamento = document.querySelector('#nombre').value;
        var estado = document.querySelector('#listEstado').value;
      

        if(departamento == '' ) {
            swal('Atencion','Todos los campos son necesarios','error');
            return false;
        }

        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/departamentos/ajax-departamentos.php';
        var form = new FormData(formDepartamentos);
        request.open('POST', url,true);
        request.send(form);
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                if(data.status){
                    $('#modalDepartamentos').modal('hide');
                    formDepartamentos.reset();
                    swal('Departamento',data.msg,'success');
                    tabledepartamentos.ajax.reload();
                } else {
                    swal('Atencion',data.msg,'error');
                }
            }
        }
    }
})

function openModalDepasssss() {
    document.querySelector('#iddepartamentos').value = "";
    document.querySelector('#tituloModal').innerHTML = 'Nuevo Departamento';
    document.querySelector('#action').innerHTML = 'Guardar';
    document.querySelector('#formDepartamentos').reset();
    $('#modalDepartamentos').modal('show');
}

function editarDepartamentos(id) {
    var iddepartamento = id;

    document.querySelector('#tituloModal').innerHTML = 'Actualizar Departamento';
    document.querySelector('#action').innerHTML = 'Actualizar';
   
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    var url = './models/departamentos/edit-departamentos.php?iddepartamentos='+iddepartamento;
    request.open('GET', url,true);
    request.send();
    request.onreadystatechange = function() {
        if(request.readyState == 4 && request.status == 200) {
            var data = JSON.parse(request.responseText);
            if(data.status){
               document.querySelector('#iddepartamentos').value = data.data.departamento_id;
               document.querySelector('#nombre').value = data.data.nombre_departamento;
               document.querySelector('#listEstado').value = data.data.estado;
                
                 $('#modalDepartamentos').modal('show');
            } else {
                swal('Atention',data.msg,'error');
            }
        }
    }

}

function eliminarDepartamentos(id) {
    var iddepartamento = id;

    swal({
        title:"Eliminar Departamento",
        text:"Realmente desea eliminar el departamento",
        type:"warning",
        showCancelButton: true,
        confirmButtonText: "Si, eliminar",
        cancelButtonText:"No, cancelar",
        closeOnConfirm: false,
        closeOnCancel: true,
    },function(confirm){
        if(confirm){
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest : new ActiveXObject('Microsoft.XMLHTTP');
            var url = './models/departamentos/delet-departamentos.php';
            request.open('POST', url,true);
            var strData = "iddepartamento="+iddepartamento;
            request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            request.send(strData);
            request.onreadystatechange = function() {
                if(request.readyState == 4 && request.status == 200) {
                    var data = JSON.parse(request.responseText);
                    if(data.status){
                        $('#modalDepartamentos').modal('hide');
                        formDepartamentos.reset();
                        swal('Eliminar',data.msg,'success');
                        tabledepartamentos.ajax.reload();
                    } else {
                        swal('Atention',data.msg,'error');
                    }
                }
            }
        }
    })
}
