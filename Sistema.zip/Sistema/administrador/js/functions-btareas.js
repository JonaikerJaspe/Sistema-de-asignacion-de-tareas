document.addEventListener('DOMContentLoaded', function() {
    var formTarea = document.querySelector('#formTarea');
    formTarea.onsubmit = function(e) {
        e.preventDefault();

        var idtarea = document.querySelector('#idtarea').value;
        var iddepartamento = document.querySelector('#iddepartamentos').value;
        var tarea = document.querySelector('#tarea').value;
        var descripcion = document.querySelector('#descripcion').value;
        var rendimiento = document.querySelector('#rendimiento').value;
        var fecha_limite = document.querySelector('#fecha_limite').value;
        var prioridad = document.querySelector('#listPrioridad').value;
       
      

        if( tarea == '' || descripcion == '' || rendimiento == '' || fecha_limite == '' ) {
            swal('Atencion','Todos los campos son necesarios','error');
            return false;
        }

        var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
        var url = './models/tareas/ajax-tareas.php';
        var form = new FormData(formTarea);
        request.open('POST', url,true);
        request.send(form);
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
             if(data.status){
                swal({
                    title: "Crear/Actualizar Tarea",
                    type: "success",
                    confirmButtonText: "Aceptar",
                    closeOnConfirm: true,
                }, function(confirm){
                    if(confirm){
                            $('#modalTarea').modal('hide');
                            location.reload();
                            formTarea.reset();               
                    }
                })
           } else {
             swal('Atencion',data.msg,'error');
           }
        }
   }
}
})

function openModalBtareas() {
    document.querySelector('#idtarea').value = "";
    document.querySelector('#tituloModal').innerHTML = 'Nueva Tarea';
    document.querySelector('#action').innerHTML = 'Guardar';
    document.querySelector('#formTarea').reset();
    $('#modalTarea').modal('show');
}

function editarTarea(id) {
    var idtarea = id;

    document.querySelector('#tituloModal').innerHTML = 'Actualizar tarea';
    document.querySelector('#action').innerHTML = 'Actualizar';
   
    var request =(window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    var url = './models/tareas/edit-tareas.php?idtarea='+idtarea;
    request.open('GET', url,true);
    request.send();
    request.onreadystatechange = function() {
        if(request.readyState == 4 && request.status == 200) {
            var data = JSON.parse(request.responseText);
            if(data.status){
                document.querySelector('#idtarea').value = data.data.tarea_id;
                document.querySelector('#iddepartamentos').value = data.data.departamento_id;
                document.querySelector('#tarea').value = data.data.tarea;
                document.querySelector('#descripcion').value = data.data.descripcion;
                document.querySelector('#rendimiento').value = data.data.rendimiento;
                document.querySelector('#fecha_limite').value = data.data.nombre_departamento;
                document.querySelector('#listPrioridad').value = data.data.prioridad;
                                
                 $('#modalTarea').modal('show');
            } else {
                swal('Atention',data.msg,'error');
            }
        }
    }

}

function eliminarTarea(id) {
    var idtarea = id;

    swal({
        title:"Eliminar tarea",
        text:"Realmente desea eliminar el tarea",
        type:"warning",
        showCancelButton: true,
        confirmButtonText: "Si, eliminar",
        cancelButtonText:"No, cancelar",
        closeOnConfirm: false,
        closeOnCancel: true,
    },function(confirm){
        if(confirm){
            var request =(window.XMLHttpRequest) ? new XMLHttpRequest : new ActiveXObject('Microsoft.XMLHTTP');
            var url = './models/tareas/delet-tareas.php';
            request.open('POST', url,true);
            var strData = "idtarea="+idtarea;
            request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            request.send(strData);
            request.onreadystatechange = function() {
                if(request.readyState == 4 && request.status == 200) {
                    var data = JSON.parse(request.responseText);
                    if(data.status){
                        swal('Eliminar',data.msg,'success');
                        location.reload();
                    } else {
                        swal('Atention',data.msg,'error');
                    }
                }
            }
        }
    })
}
