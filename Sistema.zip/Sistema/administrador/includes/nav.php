<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="imagenes/images.jpg" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?=  $_SESSION['nombre']?></p>
          <p class="app-sidebar__user-designation"><h6>Director</h6></p>
        </div>
      </div>
      <ul class="app-menu">
      <li><a class="app-menu__item" href="lista_usuarios.php"><i class="app-menu__icon fa fa-user fa"></i><span class="app-menu__label">Usuarios</span></a></li>

      <li><a class="app-menu__item" href="lista_coordinadores.php"><i class="app-menu__icon fa fa-users fa"></i><span class="app-menu__label">Coordinardores</span></a></li>

      <li><a class="app-menu__item" href="cd.php"><i class="app-menu__icon fa-solid fa-clipboard fa"></i><span class="app-menu__label">Coordinador de <br> Departamento</span></a></li>

      <li><a class="app-menu__item" href="departamentos.php"><i class="app-menu__icon fa  fa-folder-open fa"></i><span class="app-menu__label">Departamentos</span></a></li>

      <!--<li><a class="app-menu__item" href="lista_departamentos.php"><i class="app-menu__icon fa fa-file-code-o"></i><span class="app-menu__label">Departamentos</span></a></li>
      <li><a class="app-menu__item" href="lista_tareas.php"><i class="app-menu__icon fa fa-tasks"></i><span class="app-menu__label">Tarea</span></a></li>
        --><li><a class="app-menu__item" href="../logout.php"><i class="app-menu__icon fa fa-sign-out fa"></i><span class="app-menu__label">Salir</span></a></li>
      </ul>
    </aside>