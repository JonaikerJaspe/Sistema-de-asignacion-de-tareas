<!-- MODAL TAREAS-->
<div class="modal fade" id="modalTarea" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tituloModal">Tarea</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="formTarea" name="formTarea">
          <input type="hidden" name="idtarea" id="idtarea" value="">
          <input type="hidden" name="iddepartamentos" id="iddepartamentos" value="<?= $departamento; ?>">
          <div class="mb-3">
            <label for="control-label">Tarea:</label>
            <input type="text" class="form-control" name="tarea" id="tarea">
          </div>
          <div class="form-group">
            <label for="control-label">Descripcion:</label>
            <textarea class="form-control" name="descripcion" id="descripcion"  rows="4"></textarea>
          </div>   
          <div class="mb-3">
          <label for="control-label">Rendimiento:</label>
            <input type="text" class="form-control" name="rendimiento" id="rendimiento">
          </div>
          <div class="mb-3">
          <label for="control-label">Fecha limite:</label>
            <input type="date" class="form-control" name="fecha_limite" id="fecha_limite">
          </div>
          <div class="mb-3">
          <label for="listEstado">Prioridad:</label>
            <select class="form-control"name="listPrioridad" id="listPrioridad">
                <option value="1">Normal</option>
                <option value="2">Urgente</option>
                <option value="3">Inmediata</option>
            </select>
          </div>
          <div class="mb-3">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button class="btn btn-primary" id="action" type="submit">Guardar</button>
        </div>
        </form>
        </div>
      </div>

    </div>
  </div>
</div>
