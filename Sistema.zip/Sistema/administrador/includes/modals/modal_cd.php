<!-- MODAL COORDINADOR-DEPARTAMENTO-->
<div class="modal fade" id="modalCD" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tituloModal">Nuevo Departamentos</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="formCD" name="formCD">
          <input type="hidden" name="idCD" id="idCD" value="">
          <div class="mb-3">
          <label for="control-label">Departamento:</label>
          <select  class="form-control" name="listDepartamento" id="listDepartamento">
                <!-- CONTENIDO AJAX -->
            </select>
          </div>
          <div class="form-group">
          <label for="control-label">Coordinador:</label>
          <select   class="form-control" name="listCoordinadores" id="listCoordinadores">
                <!-- CONTENIDO AJAX -->
            </select>
          </div>
          <div class="mb-3">
          <label for="listEstado">Estado:</label>
            <select class="form-control" name="listEstado" id="listEstado">
                <option value="1">Activo</option>
                <option value="2">Inactivo</option>
            </select>
          </div>
          <div class="mb-3">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button class="btn btn-primary" id="action" type="submit">Guardar</button>
        </div>
        </form>
      </div>

    </div>
  </div>
</div>
