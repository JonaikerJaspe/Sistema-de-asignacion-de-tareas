<!-- MODAL TAREAS-->
<div class="modal fade" id="modalCalificacion" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tituloModal">Cargar Calificacion</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="formCalificacion" name="formCalificacion">
          <input type="hidden" name="idprogreso" id="idprogreso" value="<?= $progreso; ?>">
          <div class="form-group">
                    <label for="exampleSelect1"><h4>Calificacion:</h4></label>
                    <select name="calificacion" id="calificacion" class="form-control form-control-sm" required>
                        <?php 
                        for($i = 5; $i >= 0;$i--):
                        ?>
                        <option <?php echo isset($calificacion) && $calificacion == $i ? "selected" : '' ?>><?php echo $i ?></option>
                        <?php endfor; ?>
									</select>
                  </div>
          <div class="form-group">
            <label for="control-label"><h4>Importante:</h4></label><br>
            <p>Los cambios no podran ser editados</p>
          </div>   
          <div class="mb-3">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button class="btn btn-primary" id="action" type="submit">Guardar</button>
        </div>
        </form>
        </div>
      </div>

    </div>
  </div>
</div>
