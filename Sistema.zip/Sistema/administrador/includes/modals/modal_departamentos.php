<!-- MODAL USUARIOS-->
<div class="modal fade" id="modalDepartamentos" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tituloModal">Nuevo Departamentos</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="formDepartamentos" name="formDepartamentos">
          <input type="hidden" name="iddepartamentos" id="iddepartamentos" value="">
          <div class="mb-3">
            <label for="control-label">Departamento:</label>
            <input type="text" class="form-control" name="nombre" id="nombre">
          </div>
          <div class="form-group">
            <label for="control-label">Descripcion:</label>
            <textarea class="form-control" name="descripcion" id="descripcion"  rows="10"></textarea>
          </div>
          <div class="form-group">
          <label for="listEstado">Estado:</label>
            <select  class="form-control" name="listEstado" id="listEstado">
                <option value="1">Activo</option>
                <option value="2">Inactivo</option>
            </select>
          </div>
          <div class="mb-3">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button class="btn btn-primary" id="action" type="submit">Guardar</button>
        </div>
        </form>
      </div>

    </div>
  </div>
</div>
