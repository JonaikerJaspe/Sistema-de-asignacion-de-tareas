<!-- MODAL TAREAS-->
<div class="modal fade" id="modalobservacion" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tituloModal">Descargar Tarea</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="formCalificacion" name="formprogreso">

        <?php

        require_once '../includes/funciones.php';

        $sqlc = "SELECT * FROM progreso as p INNER JOIN coordinadores as c ON p.coordinador_id = c.coordinador_id INNER JOIN lista_tareas as eva ON p.tarea_id = eva.tarea_id INNER JOIN departamentos as d ON eva.departamento_id = d.departamento_id WHERE p.tarea_id = ? ";
        $queryc = $pdo->prepare($sqlc);
        $queryc->execute(array($tarea));
        $rowc = $query->rowCount();

        if ($rowc > 0) {
                        while($data = $queryc->fetch()){
                          ?>
                          
                              <div class = "tile-tile-w-btn">    
                                    <h4 class="title"> Coordinador/a : <?= $data['nombre']; ?></h4>
                              </div>
                              <br>
                              <hr>
                              <div class="tile-body">
                              <div class="form-group">
                                  <label for="control-label"><h4>Progreso:</h4></label><br>
                                 
                                  <b><?= $data['observacion']; ?></b> <br><br>
                                </div>   
                                  

                              </div>
                               <?php
                               
                               $material = $data['material']; 
                               if (empty($material)) {
                                $material = ''; 
                               } else {
                                $material = "<div class='input-group'>
                                <div class='input-group-prepend'>
                                  <div class='input-group-text'><i class='fa fa-download'></i></div>
                                 </div>  
                                  <a class='btn btn-primary' href=' BASE_URL<?= $material ?>' target='_blank'> Material de Descarga</a>
                                </div>";
                              }    
                              
                               ?>
                               <br>
                                <?=$material?>    
               <?php         }
                   }
        ?>
        </form>
        </div>
      </div>

    </div>
  </div>
</div>