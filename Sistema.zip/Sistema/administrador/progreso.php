<?php
if(!empty($_GET['departamento']) || empty($_GET['eva'])) {
    $departamento = $_GET['departamento'];
    $tarea = $_GET['eva'];
}else{
      header("Location: administrador/");
}
require_once 'includes/header.php';
require_once '../includes/conexion.php';
require_once '../includes/funciones.php';
//require_once 'includes/modals/modal_tareas.php';

$usuario_id = $_SESSION['id_usuario'];
        
        

 $sql = "SELECT *, date_format(fecha_limite, '%d/%m/%Y') as fecha_limite FROM lista_tareas WHERE departamento_id = $departamento AND tarea_id = $tarea";
 $query = $pdo->prepare($sql);
 $query->execute();
 $row = $query -> rowCount();


 $sqlc = "SELECT * FROM progreso as p INNER JOIN coordinadores as c ON p.coordinador_id = c.coordinador_id INNER JOIN lista_tareas as eva ON p.tarea_id = eva.tarea_id INNER JOIN departamentos as d ON eva.departamento_id = d.departamento_id WHERE p.tarea_id = ? ";
 $queryc = $pdo->prepare($sqlc);
 $queryc->execute(array($tarea));
 $rowc = $query->rowCount(); 

 date_default_timezone_set("America/Caracas");
 $fecha = date('Y-m-d');
   
?>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Progreso o Tarea completada</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Progreso o Tarea completada</a></li>
        </ul>
      </div>
      <div class="row">
        <?php if($row > 0){
              while($data = $query->fetch()){
                ?>
        <div class="col-md-12">
          <div class="tile">
          <div class="tile">
              <div class = "tile-tile-w-btn">
                    <h3 class="title"><?= $data['tarea']; ?></h3>
              </div>
              <div class="tile-body">
                  <b><?= $data['descripcion']; ?></b> <br><br>
                  <b> Fecha limite:  <kbd class="bg-info"> <?= $data['fecha_limite']; ?></kbd></b>
                  <?php
                  $fechaLimite = $data['fecha_limite'];
                  $estatus = '';
                  if($fechaLimite < $fecha){
                    $estatus  = '<span class = "badge badge-danger">Pendiente</span>';
                  }
                    
                  ?>
                  <br>
                <b> <?= $estatus ; ?></b> <br><br>
              </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
        <?php } } ?>
      </div>
                <div class="row mt-2 bg-secondary text-white p-2">
                    <h3>Progreso de la tarea</h3>
                </div>
                <div class="row mt-3">
                    <?php if ($rowc > 0) {
                        while($data2 = $queryc->fetch()){
                            $valor =  '';
                            $cargar = '';
                            $alumno = $data2['coordinador_id'];
                            $progreso = $data2['progreso_id'];

                            $sqln = "SELECT * FROM calificacion WHERE progreso_id = $progreso";
                            $queryn = $pdo->prepare($sqln);
                            $queryn->execute();
                            $datan = $queryn->rowCount();
                            if($datan > 0){ 
                                $valor = '<kbd class="bg-success">Calificado</kbd>';
                                $cargar = '';
                                $progreso = '';
                            }else{
                                require_once 'includes/modals/modal_calificacion.php';
                                require_once 'includes/modals/modal_progreso.php';
                                $valor = '<kbd class="bg-danger">Sin Calificacion</kbd>';
                                $cargar = '<button class="btn btn-warning" onclick = "modalCalificacion()">cargar calificacion</button> ';
                                $progreso = '<button class="btn btn-success" type="button" onclick="openModalobservacion()">Progreso</button> ';
                            };
                    
                    ?>

                    <div class="col-md-12">
                        <div class="tile">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>coordinador</th>
                                        <th>Observacion</th>
                                        <th>Estatus</th>
                                        <th>Cargar Calificacion</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?= $data2['nombre']?></td>
                                        <td><?=$progreso ?></td>
                                        <td><?=$valor?></td>
                                        <td><?=$cargar?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <?php } }?>

                </div>

              <div class="row">
                  <a href="beta-tarea.php?departamento=<?= $departamento?>&eva=<?= $tarea?>" class="btn btn-info"><< Volver Atras</a>
              </div>
    </main>

<?php
require_once 'includes/footer.php'
?>