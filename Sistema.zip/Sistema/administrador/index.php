<?php
require_once 'includes/header.php';
require_once '../includes/conexion.php';

$idUsuario = $_SESSION['id_usuario'];


?>

<main class="app-content">
  <div class="row">
    <div class="col-md-12 border shadow p-2 bg-info text-white">
      <h3 class="display-4"><i>Sistema de Asignación de Tareas - UNERG</i></h3>
    </div>  
  </div> 
  <div class="row">
    <div class="col-md-12 text-center border mt-3 p-4 bg-light">
                <h3><i>INICIO</i></h3>
        </div>
  </div>
  <hr>
  <br>
    <div class="row">
      <?php 
     // if ($row > 0) {
       // while ($data = $query->fetch()) {
      ?>
     <!--<div class="col-md-4 tex-center border mt-3 p-4 bg-light">
        <div class=" card m-2 shadow" style="width: 23rem;">
          <img src="images/card-school.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h4 class="card-title text-center"><?= $data['nombre_materia'] ?></h4>
            <h5 class="card-title">Grado <kbd class="bg-info"><?= $data['nombre_grado']?></kbd> - Aula <kbd class="bg-info"><?= $data['nombre_aula'] ?></kbd></h5>
            <a href="contenido.php?curso=<?= $data['pm_id']?>" class="btn btn-primary">Acceder</a>
            <a href="alumnos.php?curso=<?= $data['pm_id']?>" class="btn btn-warning">Ver Alumnos</a>
          </div>
        </div>
      </div>-->
      <div class="row">
        <div class="col-md-3">
        <div class="widget-small primary"><i class="icon fa fa-user fa"></i>
            <div class="info">
              <h5>Usuarios</h5>
              <p><b><?php $sql = "SELECT COUNT(*) FROM usuarios WHERE estado != 0";
                    $result = $pdo->query($sql); //$pdo sería el objeto conexión
                    $total = $result->fetchColumn();
                    echo $total.'<br>'; ?></b></p>
            </div>
          </div>
        </div>
          <div class="col-md-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-users fa"></i>
            <div class="info">
              <h5>Coordinadores</h5>
              <p><b><?php $sql = "SELECT COUNT(*) FROM coordinadores WHERE estado != 0";
                    $result = $pdo->query($sql); //$pdo sería el objeto conexión
                    $total = $result->fetchColumn();
                    echo $total.'<br>'; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-folder-open fa-3x"></i>
            <div class="info">
              <h5>Departamentos</h5>
              <p><b><?php $sql = "SELECT COUNT(*) FROM departamentos WHERE estado != 0";
                    $result = $pdo->query($sql); //$pdo sería el objeto conexión
                    $total = $result->fetchColumn();
                    echo $total.'<br>'; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="widget-small warning"><i class="icon fa fa-files-o fa-3x"></i>
            <div class="info">
              <h5>Tareas</h5>
              <p><b><?php $sql = "SELECT COUNT(*) FROM lista_tareas WHERE prioridad != 0";
                    $result = $pdo->query($sql); //$pdo sería el objeto conexión
                    $total = $result->fetchColumn();
                    echo $total.'<br>'; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-check fa-3x"></i>
            <div class="info">
              <h5>Progresos</h5>
              <p><b><?php $sql = "SELECT COUNT(*) FROM progreso ";
                    $result = $pdo->query($sql); //$pdo sería el objeto conexión
                    $total = $result->fetchColumn();
                    echo $total.'<br>'; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-paperclip fa-3x"></i>
            <div class="info">
              <h5>Tareas Calificadas</h5>
              <p><b><?php $sql = "SELECT COUNT(*) FROM calificacion";
                    $result = $pdo->query($sql); //$pdo sería el objeto conexión
                    $total = $result->fetchColumn();
                    echo $total.'<br>'; ?></b></p>
            </div>
          </div>
        </div>
      </div>

      <?php  //} } ?>
    </div> 
</main>

<?php
require_once 'includes/footer.php';
?>

