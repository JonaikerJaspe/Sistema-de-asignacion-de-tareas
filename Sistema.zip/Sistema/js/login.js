$(document).ready(function(){
    $('#loginUsuario').on('click',function(){
        loginUsuario();
    });
    $('#loginCoordinador').on('click',function(){
        loginCoordinador();
    });
})

function loginUsuario() {
    var login = $('#usuario').val();
    var pass = $('#pass').val();

    $.ajax({
        url: './includes/loginUsuario.php',
        method: 'POST',
        data: {
            login:login,
            pass:pass
        },
        success: function(data) {
            $('#messageUsuario').html(data);

            if(data.indexOf('Redirecting') >= 0) {
                window.location = 'administrador/';
            }
        }
    })
}

function loginCoordinador() {
    var loginCoordinador = $('#usuarioCoordinador').val();
    var passCoordinador = $('#passCoordinador').val();

    $.ajax({
        url: './includes/loginCoordinador.php',
        method: 'POST',
        data: {
            loginCoordinador:loginCoordinador,
            passCoordinador:passCoordinador
        },
        success: function(data) {
            $('#messageCoordinador').html(data);

            if(data.indexOf('Redirecting') >= 0) {
                window.location = 'coordinador/';
            }
        }
    })
}

