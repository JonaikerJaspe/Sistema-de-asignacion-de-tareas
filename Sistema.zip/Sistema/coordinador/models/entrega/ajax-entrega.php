<?php 
require_once '../../../includes/conexion.php';
if(!empty($_POST)){
    if(trim($_POST['observacion']) == ''){
      $respuesta = array('status' => false,'msg' => 'Todos los campos son necesarios');
    } else{
      $idevaluacion = $_POST['idtarea'];
      $idcoordinador = $_POST['idCoordinador'];
      $observacion = $_POST['observacion'];
      
      $material = $_FILES['file']['name'];
      $type = $_FILES['file']['type'];
      $url_temp = $_FILES['file']['tmp_name'];

      $directorio = '../../../uploads/'.rand(1000,10000);
      if(!file_exists($directorio)){
        mkdir($directorio, 0777, true);
      }

      $destino = $directorio. '/'.$material;

      if($_FILES['file']['size'] > 19000000) {
        $respuesta = array('status' => false, 'msg' => 'Solo se permiten archivos hasta 19MB');
        //estaba en 15MB pero le puse 19MB porque quien sabe si el archivo pesa mas de lo normal.
    }else{
            $sqlInsert = 'INSERT INTO progreso (tarea_id,coordinador_id,material,observacion) VALUES (?,?,?,?)';
            $queryInsert = $pdo->prepare($sqlInsert);
            $request = $queryInsert->execute(array($idevaluacion,$idcoordinador,$destino,$observacion));
                  move_uploaded_file($url_temp,$destino);
                   if($request > 0) {
                      $respuesta = array('status' => true,'msg' => 'Evaluacion enviada correctamente');
                   }
       }
    echo json_encode($respuesta,JSON_UNESCAPED_UNICODE);
    }
}