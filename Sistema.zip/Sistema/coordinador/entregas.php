<?php
 if(!empty($_GET['usuario']) || !empty($_GET['departamento'])) {
  $curso = $_GET['usuario'];
  $contenido = $_GET['departamento'];
  $evaluacion = $_GET['eva'];
} else {
    header("location: coordinador/");
  }


  require_once 'includes/header.php';
  require_once '../includes/conexion.php';

  $idCoordinador= $_SESSION['coordinador_id'];

  $sqla = "SELECT * FROM progreso as p INNER JOIN coordinadores as c ON p.coordinador_id = c.coordinador_id INNER JOIN lista_tareas as eva ON p.tarea_id = eva.tarea_id INNER JOIN departamentos as d ON eva.departamento_id = d.departamento_id WHERE p.tarea_id = ? AND c.coordinador_id= ?";
  $querya = $pdo->prepare($sqla);
  $querya->execute(array($evaluacion,$idCoordinador));
  $rowa = $querya->rowCount();

  date_default_timezone_set("America/Caracas");
  $fecha = date('Y-m-d');

  $sqlf = "SELECT * FROM lista_tareas WHERE departamento_id = $contenido AND tarea_id = $evaluacion";
  $queryf = $pdo->prepare($sqlf); 
  $queryf->execute();
  $result = $queryf->fetch();
  $fechaLimite = $result['fecha_limite'];

?>

<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Realizar Entrega</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Realizar Entrega</a></li>
        </ul>
      </div>
      
        <?php if($rowa > 0){
              while($data = $querya->fetch()){
                $valor = '';
                $calificacion = '';
                $ev_entregada = $data['progreso_id'];

                $sqln = "SELECT * FROM calificacion as c INNER JOIN progreso as p ON c.progreso_id = p.progreso_id INNER JOIN coordinadores as co ON p.coordinador_id = co.coordinador_id WHERE c.progreso_id = $ev_entregada AND co.coordinador_id = $idCoordinador";
                $queryn = $pdo->prepare($sqln);
                $queryn->execute();
                $datan = $queryn->rowCount();
                $nota = $queryn->fetch();
                if($datan > 0 ){
                    $valor = '<kbd class="bg-success">Calificador</kbd';
                    $calificacion = $nota['valor_calificacion'];
                } else { 
                    $valor = '<kbd class="bg-danger">Sin Calificar</kbd';
                    $calificacion= '';
                }
                ?>
                <div class="row mt-2 bg-success text-white p-2">
                  <h3>Ya realizo la entrega</h3>
                </div>
                <div class="row mt-3">
                  <table class="table table-bordered" >
                      <thead>
                          <tr>
                            <th>Estatus</th>
                            <th>Calificacion</th>
                          </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><p><?= $valor; ?></p></td>
                          <td><p><?= $calificacion; ?></p></td>
                        </tr>
                      </tbody>
                  </table>
                </div>




        <?php } } else { ?>
              <?php if($fecha < $fechaLimite) { ?>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="tile">
                        <h3 class="tile-title">Realizar Entrega</h3>
                        <div class="tile-body">
                          <form class="form-horizontal" id="formEntrega" name="formEntrega" enctype="multipart/form-data">
                            <input type="hidden" name="idtarea" id="idtarea" value="<?= $evaluacion; ?>">
                            <input type="hidden" name="idCoordinador" id="idCoordinador" value="<?= $idCoordinador; ?>">
                            <div class="form-group row">
                              <label class="control-label col-md-3">Descripcion de la Actividad</label>
                              <div class="col-md-8">
                                <textarea  class="form-control" name="observacion" id="observacion" rows="4" placeholder="Descripcion de la Actividad"></textarea>
                              </div>
                            </div>
                            <div class="form-group row">
                              <label  class="control-label col-md-3">Adjuntar Material</label>
                              <div class="col-md-8">
                                <input type="file" class="form-control" name="file" id="file">
                              </div>
                            </div>
                            <div class="tile-footer">
                              <div class="row">
                                <div class="col-md-8 col-md-offset-3">
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Enviar</button>&nbsp;&nbsp;&nbsp;
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                            </div>
                          </div>

                <?php } else { ?>
                    <div class="row bg-info p-3 text-white">
                      <h5>(Fecha Limite <?= $fechaLimite; ?>) Tarea Pendiente</h5>
                    </div>
                      <br>
                    <div class="row">
                    <div class="col-md-12">
                      <div class="tile">
                        <h3 class="tile-title">Realizar Entrega</h3>
                        <div class="tile-body">
                          <form class="form-horizontal" id="formEntrega" name="formEntrega" enctype="multipart/form-data">
                            <input type="hidden" name="idtarea" id="idtarea" value="<?= $evaluacion; ?>">
                            <input type="hidden" name="idCoordinador" id="idCoordinador" value="<?= $idCoordinador; ?>">
                            <div class="form-group row">
                              <label class="control-label col-md-3">Descripcion de la Actividad</label>
                              <div class="col-md-8">
                                <textarea  class="form-control" name="observacion" id="observacion" rows="4" placeholder="Descripcion de la Actividad"></textarea>
                              </div>
                            </div>
                            <div class="form-group row">
                              <label  class="control-label col-md-3">Adjuntar Material</label>
                              <div class="col-md-8">
                                <input type="file" class="form-control" name="file" id="file">
                              </div>
                            </div>
                            <div class="tile-footer">
                              <div class="row">
                                <div class="col-md-8 col-md-offset-3">
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Enviar</button>&nbsp;&nbsp;&nbsp;
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                            </div>
                          </div>

                  <?php } ?>
          <?php } ?>
               <br>
              <div class="row">
                  <a href="tareas.php?usuario=<?= $curso ?>&departamento=<?= $contenido;?>" class="btn btn-info"><< Volver Atras</a>
              </div>
    </main>

<?php
require_once 'includes/footer.php'
?>