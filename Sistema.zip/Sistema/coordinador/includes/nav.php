<?php
require_once '../includes/conexion.php';

$idCoordinador = $_SESSION['coordinador_id'];

$sql = "SELECT * FROM departamento_coordinador as dc INNER JOIN coordinadores as co ON dc.coordinador_id = co.coordinador_id INNER JOIN departamentos d ON dc.departamento_id = d.departamento_id WHERE co.coordinador_id = $idCoordinador";
$query = $pdo->prepare($sql);
$query->execute();
$row = $query->rowCount();

?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="imagenes/images.jpg" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?= $_SESSION['nombre'] ?></p>
          <p class="app-sidebar__user-designation"><h6>Coordinador</h6></p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item" href="index.php"><i class="app-menu__icon fa fa-home fa"></i><span class="app-menu__label">Inicio</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Mis tareas</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
              <?php if($row > 0) {
              while($data = $query->fetch()){
            ?>
                <li><a class="treeview-item" href="tareas.php?usuario=<? $data['dc_id'] ?>&departamento=<?= $data['departamento_id'];?> "><i class="icon fa fa-spinner"></i><?= $data['nombre_departamento']; ?></a></li>
                <?php } } ?>
          </ul>
        </li>
        <li><a class="app-menu__item" href="../logout.php"><i class="app-menu__icon fa fa-sign-out"></i><span class="app-menu__label">Salir</span></a></li>
      </ul>
    </aside>