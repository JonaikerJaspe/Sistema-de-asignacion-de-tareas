<?php
require_once 'includes/header.php';
require_once '../includes/conexion.php';

$idCoordinador = $_SESSION['coordinador_id'];

$sql = "SELECT * FROM departamento_coordinador as dc INNER JOIN coordinadores as co ON dc.coordinador_id = co.coordinador_id INNER JOIN departamentos d ON dc.departamento_id = d.departamento_id WHERE co.coordinador_id = $idCoordinador";
$query = $pdo->prepare($sql);
$query->execute();
$row = $query->rowCount();

?>

<main class="app-content">
      <div class="row">
          <div class="col-md-12 border shadow p-2 bg-info text-white">
                <h3 class="display-4"><i>Sistema de Asignación de Tareas - UNERG</i></h3>
          </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center border mt-3 p-4 bg-light">
                <h3><i>Mis Tareas<i/></h3>
        </div>
      </div>
      <div class="row">
            <?php if($row > 0) {
              while($data = $query->fetch()){
            ?>
            <div class="col-md-4 text-center border mt-3 p-4 bg-light">
               <div class="card m-2 shadow" style="width: 23rem;">
                  <img src="imagenes/informatica.webp" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h4 class="card-title text-center">Departamento: <br><br> <kbd class="bg-info"> <?= $data['nombre_departamento'] ?> </kbd></h4>
                         <a href="tareas.php?usuario=<? $data['dc_id'] ?>&departamento=<?= $data['departamento_id'];?> "  class="btn btn-primary">Acceder</a> 
                    </div>
              </div>        
            </div>
            <?php } } ?>
      </div>
    </main>


<?php
require_once 'includes/footer.php';
?>

