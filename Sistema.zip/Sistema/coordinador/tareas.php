<?php
if(!empty($_GET['departamento'])) {
    $departamento = $_GET['departamento'];
}else{
      header("Location: coordinador/");
}
require_once 'includes/header.php';
require_once '../includes/conexion.php';


$usuario_id = $_SESSION['coordinador_id'];
        
        

 $sql = "SELECT *, date_format(fecha_limite, '%d/%m/%Y') as fecha_limite FROM lista_tareas WHERE departamento_id = $departamento";
 $query = $pdo->prepare($sql);
 $query->execute();
 $row = $query->rowCount();

?>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i>Tareas</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Tarea a Evaluar</a></li>
        </ul>
      </div>
      <div class="row">
        <?php if($row > 0){
              while($data = $query->fetch()){
                ?>
        <div class="col-md-12">
          <div class="tile">
          <div class="tile">
              <div class = "tile-tile-w-btn">
                    <h3 class="title"><?= $data['tarea']; ?></h3>
                    <p><a class="btn btn-warning icon-btn" href="entregas.php?usuario=<? $data['dc_id'] ?>&departamento=<?= $data['departamento_id'];?>&eva=<?= $data['tarea_id']; ?>"><i class="fa fa-edit"></i> Ingresar Progreso </a></p>
              </div>
              <div class="tile-body">
                  <b><?= $data['descripcion']; ?></b> <br><br>
                  <b> Fecha limite:  <kbd class="bg-info"> <?= $data['fecha_limite']; ?></kbd></b><br>
                  <?php 
                  if($data['prioridad'] == 1) {
                    echo 'Prioridad: ','<span class = "badge badge-success">Normal</span>';
                } elseif ($data['prioridad'] == 2) {
                    echo 'Prioridad: ', '<span class = "badge badge-warning">Urgente</span>';
                } else{
                  echo 'Prioridad: ', '<span class = "badge badge-danger">Inmediata</span>';
              }
                  ?>
                  
              </div>
            </div>
          </div>
        </div>
        <?php  } } ?>
      </div>
              <div class="row">
                  <a href="index.php" class="btn btn-info"><< Volver Atras</a>
              </div>
    </main>

<?php
require_once 'includes/footer.php'
?>