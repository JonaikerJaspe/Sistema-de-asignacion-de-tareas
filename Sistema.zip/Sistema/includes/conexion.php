<?php
$DB_HOST = "localhost";
$DB_DATABASE = "sistema-tareas";
$DB_USERNAME = "root";
$DB_PASSWORD = "";

 try {
            
    /*$connection = "mysql:host=" . $this->host . ";dbname=" . $this->db . ";charset=" . $this->charset;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];*/
    $pdo = new PDO("mysql:host=" . $DB_HOST . ";dbname=" . $DB_DATABASE . ";charset-utf8=", $DB_USERNAME, $DB_PASSWORD);
    $pdo->setAttribute( PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}catch(Exception $e){
    'error: '.$e->getMessage();
} 
?>