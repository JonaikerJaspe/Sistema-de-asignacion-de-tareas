<?php 
session_start();
if(!empty($_POST)) {
    if(empty($_POST['login']) || empty($_POST['pass'])) { 
        echo '<br> <div class="alert alert-danger" role="alert><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>Todos los campos son necesarios</div>'; 
    } else {
        require_once 'conexion.php';
        $login = $_POST['login'];
        $pass = $_POST['pass'];

        $sql = 'SELECT * FROM usuarios WHERE usuario = ? AND estado != 0';
        $query = $pdo->prepare($sql);
        $query->execute(array($login));
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if($query->rowCount() > 0){
            if(password_verify($pass, $result['clave'])){
                if($result['estado'] == 1){
                $_SESSION['active'] = true;
                $_SESSION['id_usuario'] = $result['usuario_id'];
                $_SESSION['nombre'] = $result['usuario'];


                echo '<br> <div class="alert alert-success" role="alert><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>Redirecting</div>'; 
            } elseif ($result['estado'] == 2)  {
                echo '<br> <div class="alert alert-warning" role="alert><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>Usuario inactivo</div>'; 
            }
            }else {
                echo '<br> <div class="alert alert-danger" role="alert><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>Usuario o clave incorrectos</div>';
             }
        } else {
            echo '<br> <div class="alert alert-danger" role="alert><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>Usuario o clave incorrectos</div>';
        }
    }
}
?>